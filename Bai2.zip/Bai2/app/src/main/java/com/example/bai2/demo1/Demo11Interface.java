package com.example.bai2.demo1;

import android.graphics.Bitmap;

public interface Demo11Interface {
    void onLoadBitmap(Bitmap bitmap);// hàm load ảnh
    void onError();//Xử lý lỗi nếu có
}
