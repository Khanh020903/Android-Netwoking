package com.example.bai2.demo1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.InputStream;
import java.net.URL;

public class CNAsync extends AsyncTask<String,Void,Bitmap> {
    private Demo11Interface demo11Interface;

    public CNAsync(Demo11Interface demo11Interface, Context context) {
        this.demo11Interface = demo11Interface;
    }

    //Truyền 1 chuỗi -> lấy về ảnh
    //input
    @Override
    protected Bitmap doInBackground(String... strings) {
        try{
            //lấy về Ảnh
            return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    //output
    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if (bitmap!= null){
            demo11Interface.onLoadBitmap(bitmap);//trả kết quả cho interface
        }else {
            demo11Interface.onError();//nếu lỗi cũng trả về kết quả cho Interface
        }
    }
    //Quá Trình
    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
