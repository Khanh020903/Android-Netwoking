package com.example.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bai2.demo1.CNAsync;
import com.example.bai2.demo1.Demo11Interface;

public class MainActivity extends AppCompatActivity implements Demo11Interface,View.OnClickListener{
        Button button;
        TextView textView;
        ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.demo11textView);
        imageView = findViewById(R.id.demo11imageView);
        button = findViewById(R.id.demo11button);
        button.setOnClickListener(this);
    }
    //Khi Click vaof Button
    @Override
    public void onClick(View view) {
        new CNAsync(this,this).execute("http://tinypic.com/images/goodbye.jpg");
    }
    //Trả về kết quả
    @Override
    public void onLoadBitmap(Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
        textView.setText("Load dữ liệu Thành Công");
    }
    // Nếu có lỗi
    @Override
    public void onError() {
        textView.setText("Lỗi load dữ liệu");
    }
}